// Modified from video-shotcraft (Apache-2.0), 3ac67b75dd0b3bc2fd807c17f6b7ce35373eef3d.
// Nana exposes the original card effect independently of the upstream workbench.
import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";

// 暖白闪转场 —— 参数化版（源出 template/src/aifl/FlashCut.tsx）
// 跨骑硬切两侧各 5f 的暖白 bloom：峰值在 40% 处（FIXED）；开放峰值不透明度与暖色。

interface Props {
  peak?: number;
  color?: string;
  duration?: number;
}

export const FlashCut: React.FC<Props> = ({ peak = 0.85, color = "#fff8eb", duration = 10 }) => {
  const frame = useCurrentFrame();
  const o = interpolate(frame, [0, duration * 0.4, duration], [0, peak, 0], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  return (
    <AbsoluteFill
      style={{
        pointerEvents: "none",
        opacity: o,
        background: `radial-gradient(ellipse at 50% 45%, ${color}, ${color}8c 55%, transparent 80%)`,
      }}
    />
  );
};
